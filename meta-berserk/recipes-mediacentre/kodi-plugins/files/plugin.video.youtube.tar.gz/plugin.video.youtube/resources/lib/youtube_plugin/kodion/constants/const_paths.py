__author__ = 'bromix'

SEARCH = 'kodion/search'
FAVORITES = 'kodion/favorites'
WATCH_LATER = 'kodion/watch_later'
